package com.uts.gamevault.vista;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.BorderLayout;


public abstract class PanelModulo extends JPanel {

    protected PanelModulo(String titulo, String subtitulo) {
        super(new BorderLayout(0, 16));
        setBackground(Estilo.FONDO);
        setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));

        JPanel encabezado = new JPanel();
        encabezado.setOpaque(false);
        encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));
        JLabel lTitulo = new JLabel(titulo);
        lTitulo.setFont(Estilo.TITULO);
        lTitulo.setForeground(Estilo.TEXTO);
        JLabel lSub = new JLabel(subtitulo);
        lSub.setFont(Estilo.SUBTITULO);
        lSub.setForeground(Estilo.TEXTO_SUAVE);
        encabezado.add(lTitulo);
        encabezado.add(lSub);
        add(encabezado, BorderLayout.NORTH);
    }

  
    public abstract void refrescar();

  
    protected void setContenido(JComponent contenido) {
        add(contenido, BorderLayout.CENTER);
    }

    protected void mostrarError(String mensaje, Exception e) {
        JOptionPane.showMessageDialog(this,
                mensaje + (e == null ? "" : "\n\nDetalle: " + e.getMessage()),
                "Error", JOptionPane.ERROR_MESSAGE);
    }

    protected void mostrarInfo(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "GameVault", JOptionPane.INFORMATION_MESSAGE);
    }

    protected void mostrarAdvertencia(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Atención", JOptionPane.WARNING_MESSAGE);
    }
}
