package com.uts.gamevault.dao;

import com.uts.gamevault.conexion.Conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ConsultaDAO {

    public List<Object[]> listarUsuarios() throws SQLException {
        return consultar("SELECT identificacion, nombre, apellido, telefono, correo "
                + "FROM usuarios ORDER BY apellido, nombre", 5);
    }

    public List<Object[]> listarPrestamos() throws SQLException {
        return consultar("SELECT p.id_prestamo, u.nombre || ' ' || u.apellido, v.nombre, "
                + "p.fecha_prestamo, p.fecha_devolucion_prevista, "
                + "COALESCE(p.fecha_devolucion_real, '—'), p.estado "
                + "FROM prestamos p "
                + "JOIN usuarios u ON u.id_usuario = p.id_usuario "
                + "JOIN videojuegos v ON v.id_videojuego = p.id_videojuego "
                + "ORDER BY p.fecha_prestamo DESC", 7);
    }

    public int[] resumen() throws SQLException {
        String sql = "SELECT (SELECT COUNT(*) FROM videojuegos), "
                + "(SELECT COALESCE(SUM(cantidad_disponible),0) FROM videojuegos), "
                + "(SELECT COUNT(*) FROM usuarios), "
                + "(SELECT COUNT(*) FROM prestamos WHERE estado = 'PRESTADO')";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return new int[]{rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4)};
        }
    }

    private List<Object[]> consultar(String sql, int columnas) throws SQLException {
        List<Object[]> filas = new ArrayList<>();
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Object[] fila = new Object[columnas];
                for (int i = 0; i < columnas; i++) {
                    fila[i] = rs.getObject(i + 1);
                }
                filas.add(fila);
            }
        }
        return filas;
    }
}
