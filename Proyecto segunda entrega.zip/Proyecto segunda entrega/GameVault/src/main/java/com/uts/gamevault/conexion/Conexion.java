package com.uts.gamevault.conexion;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public final class Conexion {

    private static final String ARCHIVO_BD = "gamevault.db";
    private static final String URL = "jdbc:sqlite:" + ARCHIVO_BD;
    private static final String SCRIPT = "/db/script_gamevault.sql";

    private Conexion() {
        
    }

  
    public static Connection getConexion() throws SQLException {
        Connection cn = DriverManager.getConnection(URL);
        try (Statement st = cn.createStatement()) {
            
            st.execute("PRAGMA foreign_keys = ON");
        }
        return cn;
    }

   
    public static String getRutaBaseDatos() {
        return Paths.get(ARCHIVO_BD).toAbsolutePath().toString();
    }

  
    public static void inicializar() throws SQLException, IOException {
        Path archivo = Paths.get(ARCHIVO_BD);
        if (Files.exists(archivo) && Files.size(archivo) > 0) {
            return;
        }
        try (Connection cn = getConexion(); Statement st = cn.createStatement()) {
            cn.setAutoCommit(false);
            for (String sentencia : leerScript().split(";")) {
                if (!sentencia.isBlank()) {
                    st.execute(sentencia);
                }
            }
            cn.commit();
        }
    }

    
    private static String leerScript() throws IOException {
        InputStream in = Conexion.class.getResourceAsStream(SCRIPT);
        if (in == null) {
            throw new IOException("No se encontró el script " + SCRIPT);
        }
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                int comentario = linea.indexOf("--");
                if (comentario >= 0) {
                    linea = linea.substring(0, comentario);
                }
                sb.append(linea).append('\n');
            }
        }
        return sb.toString();
    }
}
