package com.uts.gamevault.dao;

import java.sql.SQLException;


public class OperacionNoPermitidaException extends SQLException {

    public OperacionNoPermitidaException(String mensaje) {
        super(mensaje);
    }
}
