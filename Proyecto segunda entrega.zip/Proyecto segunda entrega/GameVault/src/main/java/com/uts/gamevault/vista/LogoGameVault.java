package com.uts.gamevault.vista;

import javax.swing.JComponent;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;


public class LogoGameVault extends JComponent {

    private final int tam;

    public LogoGameVault(int tam) {
        this.tam = tam;
        setPreferredSize(new Dimension(tam, tam));
        setMinimumSize(new Dimension(tam, tam));
        setMaximumSize(new Dimension(tam, tam));
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        float s = tam / 48f;

        
        g.setPaint(new GradientPaint(0, 0, new Color(0x6366F1), tam, tam, new Color(0x0F766E)));
        g.fill(new RoundRectangle2D.Float(0, 0, tam, tam, 14 * s, 14 * s));

     
        g.setColor(Color.WHITE);
        g.fill(new RoundRectangle2D.Float(7 * s, 15 * s, 34 * s, 19 * s, 16 * s, 16 * s));

     
        g.setColor(new Color(0x1E1B2E));
        g.fillRect(Math.round(13 * s), Math.round(23 * s), Math.round(8 * s), Math.round(3 * s));
        g.fillRect(Math.round(15.5f * s), Math.round(20.5f * s), Math.round(3 * s), Math.round(8 * s));

     
        g.setColor(new Color(0x4F46E5));
        g.fillOval(Math.round(29 * s), Math.round(20 * s), Math.round(4 * s), Math.round(4 * s));
        g.setColor(new Color(0x0F766E));
        g.fillOval(Math.round(33 * s), Math.round(24 * s), Math.round(4 * s), Math.round(4 * s));

        g.setStroke(new BasicStroke(1f));
        g.dispose();
    }
}
