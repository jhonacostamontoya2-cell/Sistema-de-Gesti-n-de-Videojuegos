package com.uts.gamevault.vista;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.table.JTableHeader;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;


public final class Estilo {

    public static final Color MENU_FONDO = new Color(0x1E1B2E);
    public static final Color MENU_HOVER = new Color(0x2C2842);
    public static final Color MENU_TEXTO = new Color(0xC9C6DA);
    public static final Color ACENTO = new Color(0x4F46E5);
    public static final Color ACENTO_2 = new Color(0x0F766E);
    public static final Color PELIGRO = new Color(0xDC2626);
    public static final Color ADVERTENCIA = new Color(0xB45309);
    public static final Color FONDO = new Color(0xF4F4F8);
    public static final Color TARJETA = Color.WHITE;
    public static final Color BORDE = new Color(0xE2E1EA);
    public static final Color TEXTO = new Color(0x1F1D2B);
    public static final Color TEXTO_SUAVE = new Color(0x6B6880);

    public static final Font TITULO = new Font(Font.SANS_SERIF, Font.BOLD, 24);
    public static final Font SUBTITULO = new Font(Font.SANS_SERIF, Font.PLAIN, 13);
    public static final Font NORMAL = new Font(Font.SANS_SERIF, Font.PLAIN, 13);
    public static final Font NEGRITA = new Font(Font.SANS_SERIF, Font.BOLD, 13);

    private Estilo() {
    }

    public static Border bordeTarjeta() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDE, 1, true),
                BorderFactory.createEmptyBorder(14, 16, 14, 16));
    }

    public static JLabel etiqueta(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(NEGRITA);
        l.setForeground(TEXTO_SUAVE);
        return l;
    }

    
    public static JButton boton(String texto, Color fondo) {
        JButton b = new JButton(texto);
        b.setFont(NEGRITA);
        b.setBackground(fondo);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.putClientProperty("JButton.buttonType", "roundRect");
        return b;
    }

   
    public static JButton botonSecundario(String texto) {
        JButton b = new JButton(texto);
        b.setFont(NEGRITA);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static void configurarTabla(JTable tabla) {
        tabla.setRowHeight(30);
        tabla.setFont(NORMAL);
        tabla.setShowVerticalLines(false);
        tabla.setGridColor(BORDE);
        tabla.setSelectionBackground(new Color(0xE0DEFF));
        tabla.setSelectionForeground(TEXTO);
        tabla.setFillsViewportHeight(true);
        tabla.setAutoCreateRowSorter(true);
        tabla.getTableHeader().setReorderingAllowed(false);
        JTableHeader h = tabla.getTableHeader();
        h.setFont(NEGRITA);
        h.setBackground(new Color(0xEDECF5));
        h.setForeground(TEXTO);
    }
}
