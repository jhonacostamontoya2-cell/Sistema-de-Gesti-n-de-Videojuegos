package com.uts.gamevault.modelo;

public class Videojuego {

    private int idVideojuego;
    private String codigo;
    private String nombre;
    private Catalogo genero;
    private Catalogo plataforma;
    private int anioLanzamiento;
    private String desarrollador;
    private double precio;
    private int cantidadTotal;
    private int cantidadDisponible;

    public Videojuego() {
    }

    public Videojuego(String codigo, String nombre, Catalogo genero, Catalogo plataforma,
                      int anioLanzamiento, String desarrollador, double precio, int cantidadTotal) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.genero = genero;
        this.plataforma = plataforma;
        this.anioLanzamiento = anioLanzamiento;
        this.desarrollador = desarrollador;
        this.precio = precio;
        this.cantidadTotal = cantidadTotal;
        this.cantidadDisponible = cantidadTotal;
    }

   
    public int getCantidadPrestada() {
        return cantidadTotal - cantidadDisponible;
    }

    public boolean estaDisponible() {
        return cantidadDisponible > 0;
    }

    public int getIdVideojuego() { return idVideojuego; }
    public void setIdVideojuego(int idVideojuego) { this.idVideojuego = idVideojuego; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public Catalogo getGenero() { return genero; }
    public void setGenero(Catalogo genero) { this.genero = genero; }

    public Catalogo getPlataforma() { return plataforma; }
    public void setPlataforma(Catalogo plataforma) { this.plataforma = plataforma; }

    public int getAnioLanzamiento() { return anioLanzamiento; }
    public void setAnioLanzamiento(int anioLanzamiento) { this.anioLanzamiento = anioLanzamiento; }

    public String getDesarrollador() { return desarrollador; }
    public void setDesarrollador(String desarrollador) { this.desarrollador = desarrollador; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getCantidadTotal() { return cantidadTotal; }
    public void setCantidadTotal(int cantidadTotal) { this.cantidadTotal = cantidadTotal; }

    public int getCantidadDisponible() { return cantidadDisponible; }
    public void setCantidadDisponible(int cantidadDisponible) { this.cantidadDisponible = cantidadDisponible; }

    @Override
    public String toString() {
        return codigo + " - " + nombre;
    }
}
