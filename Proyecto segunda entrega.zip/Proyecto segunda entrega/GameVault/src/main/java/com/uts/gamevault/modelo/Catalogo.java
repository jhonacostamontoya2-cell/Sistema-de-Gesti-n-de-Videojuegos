package com.uts.gamevault.modelo;

import java.util.Objects;

public class Catalogo {

    private final int id;
    private final String nombre;

    public Catalogo(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }

    @Override
    public String toString() {
        return nombre;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Catalogo)) return false;
        return id == ((Catalogo) o).id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
