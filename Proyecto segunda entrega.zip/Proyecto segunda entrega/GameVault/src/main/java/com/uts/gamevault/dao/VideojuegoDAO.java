package com.uts.gamevault.dao;

import com.uts.gamevault.conexion.Conexion;
import com.uts.gamevault.modelo.Catalogo;
import com.uts.gamevault.modelo.Videojuego;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class VideojuegoDAO implements CrudDAO<Videojuego> {

    
    public enum Criterio {
        NOMBRE("Nombre", "v.nombre"),
        CODIGO("Código", "v.codigo"),
        GENERO("Género", "g.nombre"),
        PLATAFORMA("Plataforma", "p.nombre");

        private final String etiqueta;
        private final String columna;

        Criterio(String etiqueta, String columna) {
            this.etiqueta = etiqueta;
            this.columna = columna;
        }

        @Override
        public String toString() {
            return etiqueta;
        }
    }

    private static final String SELECT_BASE =
            "SELECT v.*, g.nombre AS genero, p.nombre AS plataforma "
            + "FROM videojuegos v "
            + "JOIN generos g ON g.id_genero = v.id_genero "
            + "JOIN plataformas p ON p.id_plataforma = v.id_plataforma ";

  

    @Override
    public int insertar(Videojuego v) throws SQLException {
        if (existeCodigo(v.getCodigo(), 0)) {
            throw new OperacionNoPermitidaException("Ya existe un videojuego con el código " + v.getCodigo() + ".");
        }
        String sql = "INSERT INTO videojuegos (codigo, nombre, id_genero, id_plataforma, anio_lanzamiento, "
                + "desarrollador, precio, cantidad_total, cantidad_disponible) VALUES (?,?,?,?,?,?,?,?,?)";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            asignarParametros(ps, v);
            ps.setInt(9, v.getCantidadTotal()); // al registrar, todas las unidades están disponibles
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                int id = rs.next() ? rs.getInt(1) : 0;
                v.setIdVideojuego(id);
                v.setCantidadDisponible(v.getCantidadTotal());
                return id;
            }
        }
    }

    

    @Override
    public List<Videojuego> listar() throws SQLException {
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(SELECT_BASE + "ORDER BY v.codigo")) {
            return leerLista(ps);
        }
    }

    @Override
    public Videojuego buscarPorId(int id) throws SQLException {
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(SELECT_BASE + "WHERE v.id_videojuego = ?")) {
            ps.setInt(1, id);
            List<Videojuego> lista = leerLista(ps);
            return lista.isEmpty() ? null : lista.get(0);
        }
    }

  
    public List<Videojuego> buscar(Criterio criterio, String texto) throws SQLException {
        String sql = SELECT_BASE + "WHERE " + criterio.columna + " LIKE ? ORDER BY v.codigo";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, "%" + texto.trim() + "%");
            return leerLista(ps);
        }
    }

   
    @Override
    public boolean actualizar(Videojuego v) throws SQLException {
        if (existeCodigo(v.getCodigo(), v.getIdVideojuego())) {
            throw new OperacionNoPermitidaException("Ya existe otro videojuego con el código " + v.getCodigo() + ".");
        }
        Videojuego actual = buscarPorId(v.getIdVideojuego());
        if (actual == null) {
            throw new OperacionNoPermitidaException("El videojuego ya no existe en la base de datos.");
        }
        int prestadas = actual.getCantidadPrestada();
        if (v.getCantidadTotal() < prestadas) {
            throw new OperacionNoPermitidaException("La cantidad total no puede ser menor que las "
                    + prestadas + " unidad(es) que están prestadas.");
        }
        String sql = "UPDATE videojuegos SET codigo=?, nombre=?, id_genero=?, id_plataforma=?, "
                + "anio_lanzamiento=?, desarrollador=?, precio=?, cantidad_total=?, cantidad_disponible=? "
                + "WHERE id_videojuego=?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            asignarParametros(ps, v);
            ps.setInt(9, v.getCantidadTotal() - prestadas);
            ps.setInt(10, v.getIdVideojuego());
            return ps.executeUpdate() > 0;
        }
    }

    @Override
    public boolean eliminar(int id) throws SQLException {
        int pendientes = contarPrestamos(id, true);
        if (pendientes > 0) {
            throw new OperacionNoPermitidaException("No se puede eliminar: el videojuego tiene "
                    + pendientes + " préstamo(s) sin devolver.");
        }
        if (contarPrestamos(id, false) > 0) {
            throw new OperacionNoPermitidaException("No se puede eliminar: el videojuego tiene historial "
                    + "de préstamos que debe conservarse.");
        }
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement("DELETE FROM videojuegos WHERE id_videojuego = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }

  

    public List<Catalogo> listarGeneros() throws SQLException {
        return listarCatalogo("SELECT id_genero, nombre FROM generos ORDER BY nombre");
    }

    public List<Catalogo> listarPlataformas() throws SQLException {
        return listarCatalogo("SELECT id_plataforma, nombre FROM plataformas ORDER BY nombre");
    }


    private boolean existeCodigo(String codigo, int idExcluir) throws SQLException {
        String sql = "SELECT COUNT(*) FROM videojuegos WHERE UPPER(codigo) = UPPER(?) AND id_videojuego <> ?";
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, codigo.trim());
            ps.setInt(2, idExcluir);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    private int contarPrestamos(int idVideojuego, boolean soloPendientes) throws SQLException {
        String sql = "SELECT COUNT(*) FROM prestamos WHERE id_videojuego = ?"
                + (soloPendientes ? " AND estado = 'PRESTADO'" : "");
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, idVideojuego);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

   
    private void asignarParametros(PreparedStatement ps, Videojuego v) throws SQLException {
        ps.setString(1, v.getCodigo().trim().toUpperCase());
        ps.setString(2, v.getNombre().trim());
        ps.setInt(3, v.getGenero().getId());
        ps.setInt(4, v.getPlataforma().getId());
        ps.setInt(5, v.getAnioLanzamiento());
        ps.setString(6, v.getDesarrollador() == null ? null : v.getDesarrollador().trim());
        ps.setDouble(7, v.getPrecio());
        ps.setInt(8, v.getCantidadTotal());
    }

    private List<Videojuego> leerLista(PreparedStatement ps) throws SQLException {
        List<Videojuego> lista = new ArrayList<>();
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Videojuego v = new Videojuego();
                v.setIdVideojuego(rs.getInt("id_videojuego"));
                v.setCodigo(rs.getString("codigo"));
                v.setNombre(rs.getString("nombre"));
                v.setGenero(new Catalogo(rs.getInt("id_genero"), rs.getString("genero")));
                v.setPlataforma(new Catalogo(rs.getInt("id_plataforma"), rs.getString("plataforma")));
                v.setAnioLanzamiento(rs.getInt("anio_lanzamiento"));
                v.setDesarrollador(rs.getString("desarrollador"));
                v.setPrecio(rs.getDouble("precio"));
                v.setCantidadTotal(rs.getInt("cantidad_total"));
                v.setCantidadDisponible(rs.getInt("cantidad_disponible"));
                lista.add(v);
            }
        }
        return lista;
    }

    private List<Catalogo> listarCatalogo(String sql) throws SQLException {
        List<Catalogo> lista = new ArrayList<>();
        try (Connection cn = Conexion.getConexion();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Catalogo(rs.getInt(1), rs.getString(2)));
            }
        }
        return lista;
    }
}
