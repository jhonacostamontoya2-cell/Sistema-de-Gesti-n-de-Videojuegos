package com.uts.gamevault;

import com.formdev.flatlaf.FlatLightLaf;
import com.uts.gamevault.conexion.Conexion;
import com.uts.gamevault.vista.MenuPrincipal;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;


public class Main {

    public static void main(String[] args) {
        FlatLightLaf.setup();
        UIManager.put("Button.arc", 10);
        UIManager.put("Component.arc", 10);
        UIManager.put("TextComponent.arc", 10);
        UIManager.put("ScrollBar.thumbArc", 999);

        try {
            Conexion.inicializar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "No fue posible crear o abrir la base de datos.\n\nDetalle: " + e.getMessage(),
                    "GameVault - Error de conexión", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        SwingUtilities.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }
}
