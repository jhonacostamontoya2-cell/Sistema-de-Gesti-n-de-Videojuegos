package com.uts.gamevault.vista;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.LinkedHashMap;
import java.util.Map;

public class MenuPrincipal extends JFrame {

    private final CardLayout tarjetas = new CardLayout();
    private final JPanel contenido = new JPanel(tarjetas);
    private final Map<String, PanelModulo> modulos = new LinkedHashMap<>();
    private final Map<String, BotonMenu> botones = new LinkedHashMap<>();

    public MenuPrincipal() {
        super("GameVault - Sistema de Gestión de Videojuegos");
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                salir();
            }
        });

        modulos.put("Inicio", new PanelInicio(this::navegar));
        modulos.put("Videojuegos", new PanelVideojuegos());
        modulos.put("Usuarios", new PanelConsulta("Usuarios",
                "Personas registradas que pueden solicitar préstamos",
                new String[]{"Identificación", "Nombre", "Apellido", "Teléfono", "Correo"},
                PanelConsulta.Fuente.USUARIOS));
        modulos.put("Préstamos", new PanelConsulta("Préstamos",
                "Historial de préstamos y devoluciones",
                new String[]{"N.º", "Usuario", "Videojuego", "Fecha préstamo", "Devolución prevista",
                        "Devuelto el", "Estado"},
                PanelConsulta.Fuente.PRESTAMOS));

        contenido.setBackground(Estilo.FONDO);
        modulos.forEach((nombre, panel) -> contenido.add(panel, nombre));

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(crearMenuLateral(), BorderLayout.WEST);
        getContentPane().add(contenido, BorderLayout.CENTER);

        setMinimumSize(new Dimension(1100, 680));
        setSize(1240, 740);
        setLocationRelativeTo(null);
        navegar("Inicio");
    }

   
    public void navegar(String nombre) {
        PanelModulo panel = modulos.get(nombre);
        if (panel == null) {
            return;
        }
        panel.refrescar();
        tarjetas.show(contenido, nombre);
        botones.forEach((n, b) -> b.setSeleccionado(n.equals(nombre)));
    }

    private JPanel crearMenuLateral() {
        JPanel menu = new JPanel();
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));
        menu.setBackground(Estilo.MENU_FONDO);
        menu.setPreferredSize(new Dimension(230, 0));
        menu.setBorder(BorderFactory.createEmptyBorder(22, 0, 18, 0));

       
        JPanel marca = new JPanel();
        marca.setOpaque(false);
        marca.setLayout(new BoxLayout(marca, BoxLayout.X_AXIS));
        marca.setAlignmentX(Component.LEFT_ALIGNMENT);
        marca.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 12));
        marca.setMaximumSize(new Dimension(230, 48));
        marca.add(new LogoGameVault(42));
        marca.add(Box.createHorizontalStrut(12));
        JPanel textos = new JPanel();
        textos.setOpaque(false);
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));
        JLabel nombre = new JLabel("GameVault");
        nombre.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 19));
        nombre.setForeground(Color.WHITE);
        JLabel lema = new JLabel("Gestión de videojuegos");
        lema.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));
        lema.setForeground(Estilo.MENU_TEXTO);
        textos.add(nombre);
        textos.add(lema);
        marca.add(textos);
        menu.add(marca);
        menu.add(Box.createVerticalStrut(30));

        JLabel seccion = new JLabel("MENÚ");
        seccion.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
        seccion.setForeground(new Color(0x7E7A99));
        seccion.setBorder(BorderFactory.createEmptyBorder(0, 24, 8, 0));
        seccion.setAlignmentX(Component.LEFT_ALIGNMENT);
        menu.add(seccion);

        for (String item : modulos.keySet()) {
            BotonMenu b = new BotonMenu(item);
            b.addActionListener(e -> navegar(item));
            botones.put(item, b);
            menu.add(b);
            menu.add(Box.createVerticalStrut(4));
        }

        menu.add(Box.createVerticalGlue());

        BotonMenu salir = new BotonMenu("Salir");
        salir.setForeground(new Color(0xF4A3A3));
        salir.addActionListener(e -> salir());
        menu.add(salir);
        menu.add(Box.createVerticalStrut(10));

        JLabel version = new JLabel("UTS · POO · 2026-2  v1.0");
        version.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 10));
        version.setForeground(new Color(0x7E7A99));
        version.setBorder(BorderFactory.createEmptyBorder(0, 24, 0, 0));
        version.setAlignmentX(Component.LEFT_ALIGNMENT);
        menu.add(version);
        return menu;
    }

  
    private void salir() {
        int r = JOptionPane.showConfirmDialog(this, "¿Desea cerrar la sesión y salir de GameVault?",
                "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (r == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this,
                    "Sesión cerrada correctamente.\nLos cambios quedaron guardados en la base de datos.\n¡Hasta pronto!",
                    "Cierre de sesión", JOptionPane.INFORMATION_MESSAGE);
            dispose();
            System.exit(0);
        }
    }

    
    private static class BotonMenu extends JButton {

        private boolean seleccionado;
        private boolean encima;

        BotonMenu(String texto) {
            super(texto);
            setHorizontalAlignment(SwingConstants.LEFT);
            setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            setForeground(Estilo.MENU_TEXTO);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(true);
            setBackground(Estilo.MENU_FONDO);
            setBorder(BorderFactory.createEmptyBorder(11, 24, 11, 12));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setAlignmentX(Component.LEFT_ALIGNMENT);
            setMaximumSize(new Dimension(230, 44));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    encima = true;
                    actualizar();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    encima = false;
                    actualizar();
                }
            });
        }

        void setSeleccionado(boolean s) {
            seleccionado = s;
            actualizar();
        }

        private void actualizar() {
            setBackground(seleccionado || encima ? Estilo.MENU_HOVER : Estilo.MENU_FONDO);
            if (!"Salir".equals(getText())) {
                setForeground(seleccionado ? Color.WHITE : Estilo.MENU_TEXTO);
            }
            setBorder(seleccionado
                    ? BorderFactory.createCompoundBorder(
                            BorderFactory.createMatteBorder(0, 4, 0, 0, Estilo.ACENTO),
                            BorderFactory.createEmptyBorder(11, 20, 11, 12))
                    : BorderFactory.createEmptyBorder(11, 24, 11, 12));
            repaint();
        }

        @Override
        protected void paintComponent(java.awt.Graphics g) {
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
            super.paintComponent(g);
        }
    }
}
