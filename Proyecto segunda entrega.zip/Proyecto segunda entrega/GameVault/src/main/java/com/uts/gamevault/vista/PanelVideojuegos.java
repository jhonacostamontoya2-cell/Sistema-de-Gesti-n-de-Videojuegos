package com.uts.gamevault.vista;

import com.uts.gamevault.dao.OperacionNoPermitidaException;
import com.uts.gamevault.dao.VideojuegoDAO;
import com.uts.gamevault.modelo.Catalogo;
import com.uts.gamevault.modelo.Videojuego;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.time.Year;
import java.util.List;
import java.util.Locale;

public class PanelVideojuegos extends PanelModulo {

    private static final NumberFormat PESOS = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("es-CO"));

    static {
        PESOS.setMaximumFractionDigits(0);
    }

    private final VideojuegoDAO dao = new VideojuegoDAO();

   
    private final JTextField txtCodigo = new JTextField();
    private final JTextField txtNombre = new JTextField();
    private final JComboBox<Catalogo> cbGenero = new JComboBox<>();
    private final JComboBox<Catalogo> cbPlataforma = new JComboBox<>();
    private final JSpinner spAnio = new JSpinner(new SpinnerNumberModel(Year.now().getValue(), 1970, 2100, 1));
    private final JTextField txtDesarrollador = new JTextField();
    private final JSpinner spPrecio = new JSpinner(new SpinnerNumberModel(0, 0, 10_000_000, 1000));
    private final JSpinner spCantidad = new JSpinner(new SpinnerNumberModel(1, 0, 999, 1));
    private final JLabel lblDisponibilidad = new JLabel(" ");

    private final JButton btnGuardar = Estilo.boton("Guardar", Estilo.ACENTO);
    private final JButton btnActualizar = Estilo.boton("Actualizar", Estilo.ACENTO_2);
    private final JButton btnEliminar = Estilo.boton("Eliminar", Estilo.PELIGRO);
    private final JButton btnLimpiar = Estilo.botonSecundario("Nuevo / Limpiar");


    private final JComboBox<VideojuegoDAO.Criterio> cbCriterio = new JComboBox<>(VideojuegoDAO.Criterio.values());
    private final JTextField txtBuscar = new JTextField(22);
    private final JLabel lblTotal = new JLabel();
    private final DefaultTableModel modelo;
    private final JTable tabla;

  
    private List<Videojuego> listaActual = List.of();
   
    private int idSeleccionado = 0;

    public PanelVideojuegos() {
        super("Videojuegos", "Registrar, consultar, buscar, modificar y eliminar videojuegos");

        modelo = new DefaultTableModel(new String[]{"Código", "Nombre", "Género", "Plataforma", "Año",
                "Desarrollador", "Precio", "Total", "Disponibles"}, 0) {
            @Override
            public boolean isCellEditable(int fila, int col) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int col) {
                return col == 4 || col >= 7 ? Integer.class : col == 6 ? Double.class : String.class;
            }
        };
        tabla = new JTable(modelo);
        Estilo.configurarTabla(tabla);
        configurarColumnas();

        JPanel cuerpo = new JPanel(new BorderLayout(0, 16));
        cuerpo.setOpaque(false);
        cuerpo.add(crearFormulario(), BorderLayout.NORTH);
        cuerpo.add(crearListado(), BorderLayout.CENTER);
        setContenido(cuerpo);

        registrarEventos();
        modoRegistro();
    }

    
    private JPanel crearFormulario() {
        JPanel tarjeta = new JPanel(new BorderLayout(0, 12));
        tarjeta.setBackground(Estilo.TARJETA);
        tarjeta.setBorder(Estilo.bordeTarjeta());

        ((JSpinner.DefaultEditor) spAnio.getEditor()).getTextField().setHorizontalAlignment(SwingConstants.LEFT);
        spAnio.setEditor(new JSpinner.NumberEditor(spAnio, "#"));
        JSpinner.NumberEditor editorPrecio = new JSpinner.NumberEditor(spPrecio, "$ #,##0");
        editorPrecio.getFormat().setDecimalFormatSymbols(
                new java.text.DecimalFormatSymbols(Locale.forLanguageTag("es-CO")));
        spPrecio.setEditor(editorPrecio);

        JPanel campos = new JPanel(new GridBagLayout());
        campos.setOpaque(false);
        agregarCampo(campos, 0, 0, "Código *", txtCodigo, 1);
        agregarCampo(campos, 1, 0, "Nombre *", txtNombre, 2);
        agregarCampo(campos, 3, 0, "Desarrollador", txtDesarrollador, 1);
        agregarCampo(campos, 0, 2, "Género *", cbGenero, 1);
        agregarCampo(campos, 1, 2, "Plataforma *", cbPlataforma, 1);
        agregarCampo(campos, 2, 2, "Año de lanzamiento", spAnio, 1);
        agregarCampo(campos, 3, 2, "Precio (COP)", spPrecio, 1);
        agregarCampo(campos, 0, 4, "Cantidad total *", spCantidad, 1);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 5;
        c.gridwidth = 3;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(0, 8, 0, 8);
        lblDisponibilidad.setFont(Estilo.NEGRITA);
        campos.add(lblDisponibilidad, c);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botones.setOpaque(false);
        botones.add(btnLimpiar);
        botones.add(btnEliminar);
        botones.add(btnActualizar);
        botones.add(btnGuardar);

        tarjeta.add(campos, BorderLayout.CENTER);
        tarjeta.add(botones, BorderLayout.SOUTH);
        return tarjeta;
    }

    private void agregarCampo(JPanel panel, int col, int fila, String etiqueta, JComponent campo, int ancho) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = col;
        c.gridy = fila;
        c.gridwidth = ancho;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 8, 2, 8);
        panel.add(Estilo.etiqueta(etiqueta), c);
        c.gridy = fila + 1;
        c.insets = new Insets(0, 8, 12, 8);
        campo.setFont(Estilo.NORMAL);
        campo.putClientProperty("JComponent.minimumWidth", 140);
        panel.add(campo, c);
    }

    private JPanel crearListado() {
        JPanel tarjeta = new JPanel(new BorderLayout(0, 10));
        tarjeta.setBackground(Estilo.TARJETA);
        tarjeta.setBorder(Estilo.bordeTarjeta());

        JPanel barra = new JPanel(new BorderLayout());
        barra.setOpaque(false);
        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        busqueda.setOpaque(false);
        busqueda.add(Estilo.etiqueta("Buscar por"));
        busqueda.add(cbCriterio);
        txtBuscar.putClientProperty("JTextField.placeholderText", "Escriba para filtrar...");
        txtBuscar.putClientProperty("JTextField.showClearButton", true);
        busqueda.add(txtBuscar);
        lblTotal.setFont(Estilo.NEGRITA);
        lblTotal.setForeground(Estilo.TEXTO_SUAVE);
        barra.add(busqueda, BorderLayout.WEST);
        barra.add(lblTotal, BorderLayout.EAST);

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(Estilo.BORDE));
        tarjeta.add(barra, BorderLayout.NORTH);
        tarjeta.add(scroll, BorderLayout.CENTER);
        return tarjeta;
    }

    private void configurarColumnas() {
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        int[] anchos = {65, 250, 120, 125, 50, 150, 95, 50, 95};
        for (int i = 0; i < anchos.length; i++) {
            tabla.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
        }
        DefaultTableCellRenderer precio = new DefaultTableCellRenderer() {
            @Override
            protected void setValue(Object valor) {
                setText(valor == null ? "" : PESOS.format(valor));
            }
        };
        precio.setHorizontalAlignment(SwingConstants.RIGHT);
        tabla.getColumnModel().getColumn(6).setCellRenderer(precio);

        DefaultTableCellRenderer centrado = new DefaultTableCellRenderer();
        centrado.setHorizontalAlignment(SwingConstants.CENTER);
        tabla.getColumnModel().getColumn(4).setCellRenderer(centrado);
        tabla.getColumnModel().getColumn(7).setCellRenderer(centrado);

      
        tabla.getColumnModel().getColumn(8).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foco,
                                                           int fila, int col) {
                super.getTableCellRendererComponent(t, v, sel, foco, fila, col);
                setHorizontalAlignment(SwingConstants.CENTER);
                setFont(Estilo.NEGRITA);
                setForeground(Integer.valueOf(0).equals(v) ? Estilo.PELIGRO : Estilo.ACENTO_2);
                return this;
            }
        });
    }

    private void registrarEventos() {
        btnGuardar.addActionListener(e -> guardar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> {
            modoRegistro();
            tabla.clearSelection();
        });

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                int fila = tabla.convertRowIndexToModel(tabla.getSelectedRow());
                cargarEnFormulario(listaActual.get(fila));
            }
        });

        txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { cargarTabla(); }
            @Override public void removeUpdate(DocumentEvent e) { cargarTabla(); }
            @Override public void changedUpdate(DocumentEvent e) { cargarTabla(); }
        });
        cbCriterio.addActionListener(e -> cargarTabla());
    }

 

    @Override
    public void refrescar() {
        try {
            Catalogo g = (Catalogo) cbGenero.getSelectedItem();
            Catalogo p = (Catalogo) cbPlataforma.getSelectedItem();
            cbGenero.removeAllItems();
            cbPlataforma.removeAllItems();
            dao.listarGeneros().forEach(cbGenero::addItem);
            dao.listarPlataformas().forEach(cbPlataforma::addItem);
            if (g != null) cbGenero.setSelectedItem(g);
            if (p != null) cbPlataforma.setSelectedItem(p);
        } catch (SQLException e) {
            mostrarError("No fue posible cargar los géneros y plataformas.", e);
        }
        cargarTabla();
    }

    private void cargarTabla() {
        try {
            String texto = txtBuscar.getText();
            listaActual = texto.isBlank()
                    ? dao.listar()
                    : dao.buscar((VideojuegoDAO.Criterio) cbCriterio.getSelectedItem(), texto);
            modelo.setRowCount(0);
            for (Videojuego v : listaActual) {
                modelo.addRow(new Object[]{v.getCodigo(), v.getNombre(), v.getGenero().getNombre(),
                        v.getPlataforma().getNombre(), v.getAnioLanzamiento(), v.getDesarrollador(),
                        v.getPrecio(), v.getCantidadTotal(), v.getCantidadDisponible()});
            }
            lblTotal.setText(listaActual.size() + " videojuego(s)");
            seleccionarFila(idSeleccionado);
        } catch (SQLException e) {
            mostrarError("No fue posible consultar los videojuegos.", e);
        }
    }

    private void seleccionarFila(int id) {
        for (int i = 0; i < listaActual.size(); i++) {
            if (listaActual.get(i).getIdVideojuego() == id) {
                int vista = tabla.convertRowIndexToView(i);
                tabla.setRowSelectionInterval(vista, vista);
                tabla.scrollRectToVisible(tabla.getCellRect(vista, 0, true));
                return;
            }
        }
    }

 

    private void guardar() {
        Videojuego v = leerFormulario();
        if (v == null) return;
        try {
            dao.insertar(v);
            mostrarInfo("Videojuego \"" + v.getNombre() + "\" registrado correctamente.");
            txtBuscar.setText("");
            idSeleccionado = v.getIdVideojuego();
            cargarTabla();
        } catch (OperacionNoPermitidaException e) {
            mostrarAdvertencia(e.getMessage());
            txtCodigo.requestFocus();
        } catch (SQLException e) {
            mostrarError("No se pudo registrar el videojuego.", e);
        }
    }

    private void actualizar() {
        if (idSeleccionado == 0) {
            mostrarAdvertencia("Seleccione en la tabla el videojuego que desea modificar.");
            return;
        }
        Videojuego v = leerFormulario();
        if (v == null) return;
        v.setIdVideojuego(idSeleccionado);
        try {
            if (dao.actualizar(v)) {
                mostrarInfo("Videojuego actualizado correctamente.");
                cargarTabla();
            }
        } catch (OperacionNoPermitidaException e) {
            mostrarAdvertencia(e.getMessage());
        } catch (SQLException e) {
            mostrarError("No se pudo actualizar el videojuego.", e);
        }
    }

    private void eliminar() {
        if (idSeleccionado == 0) {
            mostrarAdvertencia("Seleccione en la tabla el videojuego que desea eliminar.");
            return;
        }
        int r = JOptionPane.showConfirmDialog(this,
                "¿Eliminar definitivamente \"" + txtNombre.getText().trim() + "\"?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (r != JOptionPane.YES_OPTION) return;
        try {
            if (dao.eliminar(idSeleccionado)) {
                mostrarInfo("Videojuego eliminado.");
                modoRegistro();
                cargarTabla();
            }
        } catch (OperacionNoPermitidaException e) {
            mostrarAdvertencia(e.getMessage());
        } catch (SQLException e) {
            mostrarError("No se pudo eliminar el videojuego.", e);
        }
    }

    private Videojuego leerFormulario() {
        String codigo = txtCodigo.getText().trim();
        String nombre = txtNombre.getText().trim();
        if (codigo.isEmpty()) {
            return invalido("El código es obligatorio.", txtCodigo);
        }
        if (!codigo.matches("[A-Za-z0-9-]{2,15}")) {
            return invalido("El código solo puede tener letras, números y guiones (2 a 15 caracteres).", txtCodigo);
        }
        if (nombre.isEmpty()) {
            return invalido("El nombre es obligatorio.", txtNombre);
        }
        if (nombre.length() > 100) {
            return invalido("El nombre no puede superar 100 caracteres.", txtNombre);
        }
        if (cbGenero.getSelectedItem() == null || cbPlataforma.getSelectedItem() == null) {
            return invalido("Seleccione el género y la plataforma.", cbGenero);
        }
        try {
            spAnio.commitEdit();
            spPrecio.commitEdit();
            spCantidad.commitEdit();
        } catch (java.text.ParseException e) {
            return invalido("Revise el año, el precio y la cantidad: deben ser números válidos.", spPrecio);
        }
        return new Videojuego(codigo, nombre,
                (Catalogo) cbGenero.getSelectedItem(), (Catalogo) cbPlataforma.getSelectedItem(),
                ((Number) spAnio.getValue()).intValue(), txtDesarrollador.getText().trim(),
                ((Number) spPrecio.getValue()).doubleValue(), ((Number) spCantidad.getValue()).intValue());
    }

    private Videojuego invalido(String mensaje, JComponent campo) {
        mostrarAdvertencia(mensaje);
        campo.requestFocus();
        return null;
    }

    private void cargarEnFormulario(Videojuego v) {
        idSeleccionado = v.getIdVideojuego();
        txtCodigo.setText(v.getCodigo());
        txtNombre.setText(v.getNombre());
        cbGenero.setSelectedItem(v.getGenero());
        cbPlataforma.setSelectedItem(v.getPlataforma());
        spAnio.setValue(v.getAnioLanzamiento());
        txtDesarrollador.setText(v.getDesarrollador());
        spPrecio.setValue((int) Math.round(v.getPrecio()));
        spCantidad.setValue(v.getCantidadTotal());
        lblDisponibilidad.setForeground(v.estaDisponible() ? Estilo.ACENTO_2 : Estilo.PELIGRO);
        lblDisponibilidad.setText("Disponibles: " + v.getCantidadDisponible()
                + "   ·   Prestadas: " + v.getCantidadPrestada());
        btnGuardar.setEnabled(false);
        btnActualizar.setEnabled(true);
        btnEliminar.setEnabled(true);
    }

    private void modoRegistro() {
        idSeleccionado = 0;
        txtCodigo.setText("");
        txtNombre.setText("");
        txtDesarrollador.setText("");
        if (cbGenero.getItemCount() > 0) cbGenero.setSelectedIndex(0);
        if (cbPlataforma.getItemCount() > 0) cbPlataforma.setSelectedIndex(0);
        spAnio.setValue(Year.now().getValue());
        spPrecio.setValue(0);
        spCantidad.setValue(1);
        lblDisponibilidad.setForeground(Estilo.TEXTO_SUAVE);
        lblDisponibilidad.setText("Nuevo registro: todas las unidades quedan disponibles.");
        btnGuardar.setEnabled(true);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);
        txtCodigo.requestFocusInWindow();
    }
}
