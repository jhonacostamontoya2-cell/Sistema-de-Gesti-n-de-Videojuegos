package com.uts.gamevault.vista;

import com.uts.gamevault.dao.ConsultaDAO;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.sql.SQLException;
import java.util.List;


public class PanelConsulta extends PanelModulo {

    public enum Fuente { USUARIOS, PRESTAMOS }

    private final ConsultaDAO dao = new ConsultaDAO();
    private final Fuente fuente;
    private final DefaultTableModel modelo;
    private final JLabel total = new JLabel();

    public PanelConsulta(String titulo, String subtitulo, String[] columnas, Fuente fuente) {
        super(titulo, subtitulo);
        this.fuente = fuente;

        modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int col) {
                return false;
            }
        };
        JTable tabla = new JTable(modelo);
        Estilo.configurarTabla(tabla);
        if (fuente == Fuente.PRESTAMOS) {
            tabla.getColumnModel().getColumn(columnas.length - 1).setCellRenderer(new RenderEstado());
            int[] anchos = {45, 150, 240, 110, 130, 100, 100};
            for (int i = 0; i < anchos.length; i++) {
                tabla.getColumnModel().getColumn(i).setPreferredWidth(anchos[i]);
            }
        }

        JPanel aviso = new JPanel(new BorderLayout());
        aviso.setBackground(new Color(0xFFF7E6));
        aviso.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xF5D9A8), 1, true),
                BorderFactory.createEmptyBorder(10, 14, 10, 14)));
        JLabel lAviso = new JLabel("<html><b>Módulo en construcción.</b> Esta tabla muestra los datos de ejemplo "
                + "de la base de datos; registrar, modificar y eliminar se habilitará en la próxima entrega.</html>");
        lAviso.setFont(Estilo.NORMAL);
        lAviso.setForeground(new Color(0x7A4A00));
        aviso.add(lAviso);

        total.setFont(Estilo.NEGRITA);
        total.setForeground(Estilo.TEXTO_SUAVE);

        JPanel tarjeta = new JPanel(new BorderLayout(0, 10));
        tarjeta.setBackground(Estilo.TARJETA);
        tarjeta.setBorder(Estilo.bordeTarjeta());
        tarjeta.add(total, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(BorderFactory.createLineBorder(Estilo.BORDE));
        tarjeta.add(scroll, BorderLayout.CENTER);

        JPanel cuerpo = new JPanel(new BorderLayout(0, 14));
        cuerpo.setOpaque(false);
        cuerpo.add(aviso, BorderLayout.NORTH);
        cuerpo.add(tarjeta, BorderLayout.CENTER);
        setContenido(cuerpo);
    }

    @Override
    public void refrescar() {
        try {
            List<Object[]> filas = fuente == Fuente.USUARIOS ? dao.listarUsuarios() : dao.listarPrestamos();
            modelo.setRowCount(0);
            filas.forEach(modelo::addRow);
            total.setText(filas.size() + " registro(s)");
        } catch (SQLException e) {
            mostrarError("No fue posible consultar la base de datos.", e);
        }
    }

   
    private static class RenderEstado extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object valor, boolean sel, boolean foco,
                                                       int fila, int col) {
            super.getTableCellRendererComponent(t, valor, sel, foco, fila, col);
            setFont(Estilo.NEGRITA);
            setForeground("PRESTADO".equals(valor) ? Estilo.ADVERTENCIA : Estilo.ACENTO_2);
            return this;
        }
    }
}
