package com.uts.gamevault.vista;

import com.uts.gamevault.conexion.Conexion;
import com.uts.gamevault.dao.ConsultaDAO;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.util.function.Consumer;


public class PanelInicio extends PanelModulo {

    private final ConsultaDAO dao = new ConsultaDAO();
    private final JLabel[] valores = new JLabel[4];
    private final JLabel estadoConexion = new JLabel();

    public PanelInicio(Consumer<String> navegar) {
        super("Bienvenido a GameVault", "Panel administrativo para el control de videojuegos, usuarios y préstamos");

        JPanel cuerpo = new JPanel();
        cuerpo.setOpaque(false);
        cuerpo.setLayout(new BoxLayout(cuerpo, BoxLayout.Y_AXIS));

       
        JPanel indicadores = new JPanel(new GridLayout(1, 4, 16, 0));
        indicadores.setOpaque(false);
        indicadores.setAlignmentX(Component.LEFT_ALIGNMENT);
        String[] titulos = {"Títulos registrados", "Unidades disponibles", "Usuarios", "Préstamos activos"};
        Color[] colores = {Estilo.ACENTO, Estilo.ACENTO_2, new Color(0x7C3AED), Estilo.ADVERTENCIA};
        for (int i = 0; i < 4; i++) {
            indicadores.add(crearIndicador(i, titulos[i], colores[i]));
        }
        indicadores.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 120));
        cuerpo.add(indicadores);
        cuerpo.add(Box.createVerticalStrut(20));

      
        JPanel accesos = new JPanel(new BorderLayout(0, 12));
        accesos.setBackground(Estilo.TARJETA);
        accesos.setBorder(Estilo.bordeTarjeta());
        accesos.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel tAccesos = new JLabel("Accesos rápidos");
        tAccesos.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        tAccesos.setForeground(Estilo.TEXTO);
        accesos.add(tAccesos, BorderLayout.NORTH);
        JPanel filaBotones = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        filaBotones.setOpaque(false);
        JButton bVid = Estilo.boton("Gestionar videojuegos", Estilo.ACENTO);
        bVid.addActionListener(e -> navegar.accept("Videojuegos"));
        JButton bUsu = Estilo.botonSecundario("Ver usuarios");
        bUsu.addActionListener(e -> navegar.accept("Usuarios"));
        JButton bPre = Estilo.botonSecundario("Ver préstamos");
        bPre.addActionListener(e -> navegar.accept("Préstamos"));
        filaBotones.add(bVid);
        filaBotones.add(Box.createHorizontalStrut(10));
        filaBotones.add(bUsu);
        filaBotones.add(Box.createHorizontalStrut(10));
        filaBotones.add(bPre);
        accesos.add(filaBotones, BorderLayout.CENTER);
        accesos.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 110));
        cuerpo.add(accesos);
        cuerpo.add(Box.createVerticalStrut(20));

       
        JPanel info = new JPanel();
        info.setLayout(new BoxLayout(info, BoxLayout.Y_AXIS));
        info.setBackground(Estilo.TARJETA);
        info.setBorder(Estilo.bordeTarjeta());
        info.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel tInfo = new JLabel("Información del sistema");
        tInfo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        tInfo.setForeground(Estilo.TEXTO);
        info.add(tInfo);
        info.add(Box.createVerticalStrut(10));
        estadoConexion.setFont(Estilo.NORMAL);
        info.add(estadoConexion);
        info.add(Box.createVerticalStrut(6));
        JLabel modulos = new JLabel("<html>Módulo <b>Videojuegos</b>: CRUD completo con búsqueda. "
                + "Módulos <b>Usuarios</b> y <b>Préstamos</b>: consulta (CRUD en la próxima entrega).</html>");
        modulos.setFont(Estilo.NORMAL);
        modulos.setForeground(Estilo.TEXTO_SUAVE);
        info.add(modulos);
        info.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 140));
        cuerpo.add(info);
        cuerpo.add(Box.createVerticalGlue());

        setContenido(cuerpo);
    }

    private JPanel crearIndicador(int i, String titulo, Color color) {
        JPanel tarjeta = new JPanel(new BorderLayout(0, 6));
        tarjeta.setBackground(Estilo.TARJETA);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 0, 0, color),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(4, 0, 0, 0, color),
                        Estilo.bordeTarjeta())));
        JLabel t = new JLabel(titulo);
        t.setFont(Estilo.NEGRITA);
        t.setForeground(Estilo.TEXTO_SUAVE);
        valores[i] = new JLabel("0");
        valores[i].setFont(new Font(Font.SANS_SERIF, Font.BOLD, 34));
        valores[i].setForeground(color);
        tarjeta.add(t, BorderLayout.NORTH);
        tarjeta.add(valores[i], BorderLayout.CENTER);
        return tarjeta;
    }

    @Override
    public void refrescar() {
        try {
            int[] r = dao.resumen();
            for (int i = 0; i < 4; i++) {
                valores[i].setText(String.valueOf(r[i]));
            }
            estadoConexion.setText("<html><font color='#0F766E'>● Conectado</font> a SQLite: "
                    + Conexion.getRutaBaseDatos() + "</html>");
        } catch (SQLException e) {
            estadoConexion.setText("<html><font color='#DC2626'>● Sin conexión</font>: " + e.getMessage() + "</html>");
        }
    }
}
