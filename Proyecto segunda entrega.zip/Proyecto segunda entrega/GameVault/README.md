# 🎮 GameVault – Sistema de Gestión de Videojuegos

**Proyecto del Taller de Panel Administrativo**  
Tecnología de Desarrollos de Sistemas Informáticos – Programación Orientada a Objetos  
📅 II Semestre 2026  
👨‍🏫 Profesor: Mag. Carlos Adolfo Beltrán Castro  
👨‍💻 Estudiante: Jhon Sebastián Acosta Montoya

* Cédula: 1091658536
* Correo: jhonsacosta@uts.edu.co
* Teléfono: 3192777945

![Pantalla inicial con el menú del proyecto](docs/img/pantalla_inicio.png)
*Pantalla inicial con el menú del proyecto*

---

## 🚀 Descripción del Proyecto

Este proyecto simula un panel administrativo para el **control de una colección de videojuegos**, sus **usuarios** y los **préstamos y devoluciones**, desarrollado con **Java SE** y **Swing**.

* **Swing** con un menú lateral de navegación moderna entre las diferentes secciones (cambio de pantallas con `CardLayout`).
* **Conexión a base de datos SQLite** por JDBC. La base de datos se crea sola la primera vez que se ejecuta la aplicación, a partir del script incluido.
* **CRUD de Videojuegos** completo y conectado a la base de datos: registrar, consultar, buscar (por nombre, código, género o plataforma), modificar y eliminar, con validaciones y control de disponibilidad.
* Módulos de **Usuarios** y **Préstamos** en modo consulta, mostrando los datos reales de la base; su CRUD completo se implementa en la próxima entrega.

### Funcionalidades de esta entrega

| Requisito de la entrega | Estado | Dónde está |
|---|---|---|
| Script de la base de datos | ✅ | [`database/script_gamevault.sql`](database/script_gamevault.sql) |
| Diagrama Entidad-Relación | ✅ | [`database/diagrama_er.png`](database/diagrama_er.png) |
| Gestión del Menú | ✅ | `vista/MenuPrincipal.java` |
| Conexión a Base de Datos | ✅ | `conexion/Conexion.java` |
| CRUD funcionando con la Base de Datos | ✅ Videojuegos | `dao/VideojuegoDAO.java`, `vista/PanelVideojuegos.java` |

### Reglas de negocio implementadas en el CRUD

* Campos obligatorios: código, nombre, género, plataforma y cantidad (RF15).
* El código es único y no se permiten duplicados, sin importar mayúsculas o minúsculas.
* Al registrar un videojuego, todas sus unidades quedan disponibles.
* Al modificar la cantidad total, las unidades disponibles se ajustan solas; no se puede dejar una cantidad menor que la que está prestada (RF11, RF12).
* No se puede eliminar un videojuego con préstamos pendientes ni con historial de préstamos (RF04).
* La búsqueda filtra la tabla mientras se escribe (RF05).

---

## 🗄️ Base de Datos

Motor: **SQLite 3** (archivo `gamevault.db`). Cinco tablas con llaves foráneas activadas:

* `generos` y `plataformas`: catálogos que alimentan las listas desplegables.
* `videojuegos`: información de cada título, cantidad total y disponible.
* `usuarios`: personas que pueden solicitar préstamos.
* `prestamos`: relación entre usuario y videojuego, con fechas y estado (`PRESTADO` / `DEVUELTO`).

![Diagrama Entidad-Relación](docs/img/diagrama_er.png)

El script incluye datos de ejemplo: 8 géneros, 4 plataformas, 8 videojuegos, 4 usuarios y 5 préstamos.

---

## 📂 Estructura del Proyecto

* **Lista de Menú de Opciones** con logo e ítems de navegación:
  * Inicio
  * Videojuegos
  * Usuarios
  * Préstamos
* **Vistas**
  * **Inicio**: indicadores (títulos, unidades disponibles, usuarios, préstamos activos), accesos rápidos y estado de la conexión.
  * **CRUD** con tablas de ejemplo en **Videojuegos** (completo), **Usuarios** y **Préstamos** (consulta).
* **Salir** con confirmación y mensaje informativo de cierre de sesión.

```
GameVault/
├── pom.xml                         ← dependencias (SQLite JDBC, FlatLaf)
├── database/
│   ├── script_gamevault.sql        ← script de creación + datos de ejemplo
│   ├── diagrama_er.png             ← diagrama entidad-relación
│   └── diagrama_er.dot             ← fuente del diagrama (Graphviz)
├── docs/img/                       ← capturas de pantalla
└── src/main/
    ├── resources/db/script_gamevault.sql
    └── java/com/uts/gamevault/
        ├── Main.java               ← punto de entrada
        ├── conexion/
        │   └── Conexion.java       ← conexión JDBC y creación de la BD
        ├── modelo/
        │   ├── Videojuego.java     ← entidad
        │   └── Catalogo.java       ← género / plataforma
        ├── dao/
        │   ├── CrudDAO.java        ← interfaz genérica CRUD
        │   ├── VideojuegoDAO.java  ← CRUD de videojuegos
        │   ├── ConsultaDAO.java    ← consultas de usuarios, préstamos e indicadores
        │   └── OperacionNoPermitidaException.java
        └── vista/
            ├── MenuPrincipal.java  ← ventana con menú lateral
            ├── PanelModulo.java    ← clase base abstracta de las pantallas
            ├── PanelInicio.java
            ├── PanelVideojuegos.java
            ├── PanelConsulta.java  ← Usuarios y Préstamos
            ├── LogoGameVault.java
            └── Estilo.java         ← colores y fuentes
```

### Principios de POO aplicados

* **Encapsulamiento**: atributos privados con getters y setters en las clases del modelo.
* **Abstracción e interfaces**: `CrudDAO<T>` define las operaciones que implementa cada DAO.
* **Herencia**: todas las pantallas heredan de `PanelModulo`; la excepción propia hereda de `SQLException`.
* **Polimorfismo**: el menú llama `refrescar()` sobre cualquier `PanelModulo` y cada pantalla lo resuelve a su manera.
* **Separación por capas**: modelo, acceso a datos (DAO), conexión y vista en paquetes distintos.

### Capturas

| CRUD de Videojuegos | Usuarios | Préstamos |
|---|---|---|
| ![CRUD](docs/img/crud_videojuegos.png) | ![Usuarios](docs/img/usuarios.png) | ![Préstamos](docs/img/prestamos.png) |

---

## 🧰 Lista de Tecnologías Usadas

* **Java 17** (compatible con JDK 17 o superior)
* **Java Swing** para la interfaz gráfica
* **SQLite 3** como base de datos
* **SQLite JDBC** (`org.xerial:sqlite-jdbc` 3.46.1.3) como driver de conexión
* **FlatLaf** 3.5.4 como apariencia moderna de Swing
* **Apache Maven** para la gestión de dependencias
* **NetBeans IDE** como entorno de desarrollo
* **Git y GitHub** para el control de versiones
* **Graphviz** para el diagrama entidad-relación

---

## 🔧 Instalación y ejecución

### Requisitos

* JDK 17 o superior
* NetBeans IDE (incluye Maven) y conexión a internet la primera vez, para descargar las dependencias

### Pasos en NetBeans

1. Clonar el repositorio:
   ```bash
   git clone https://github.com/jhonacostamontoya2-cell/Sistema-de-Gesti-n-de-Videojuegos.git
   ```
2. En NetBeans: **File → Open Project** y seleccionar la carpeta del proyecto (NetBeans lo reconoce como proyecto Maven por el `pom.xml`).
3. Clic derecho sobre el proyecto → **Build with Dependencies** para descargar SQLite JDBC y FlatLaf.
4. Ejecutar con **Run Project (F6)**. La clase principal es `com.uts.gamevault.Main`.
5. La primera vez se crea el archivo `gamevault.db` en la carpeta del proyecto con los datos de ejemplo.

### Desde la terminal

```bash
mvn clean package
java -jar target/GameVault-1.0.jar
```

### Reiniciar la base de datos

Cerrar la aplicación y borrar el archivo `gamevault.db`; al volver a abrirla se crea de nuevo desde el script. También se puede crear a mano con:

```bash
sqlite3 gamevault.db < database/script_gamevault.sql
```

Para ver las tablas se puede usar **DB Browser for SQLite**.
